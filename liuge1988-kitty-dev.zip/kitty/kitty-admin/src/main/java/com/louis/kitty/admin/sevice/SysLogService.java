package com.louis.kitty.admin.sevice;

import com.louis.kitty.admin.model.SysLog;
import com.louis.kitty.core.service.CurdService;

public interface SysLogService extends CurdService<SysLog> {

}
