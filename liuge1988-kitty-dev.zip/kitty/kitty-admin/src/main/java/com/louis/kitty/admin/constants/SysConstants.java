package com.louis.kitty.admin.constants;

public interface SysConstants {

	/**
	 * 系统管理员用户名
	 */
	String ADMIN = "admin";
	
}
